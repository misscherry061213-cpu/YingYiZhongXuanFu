package com.example.screentranslate.translate

import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * 翻译助手：优先使用 ML Kit 离线翻译（en → zh），
 * 失败或无模型时尝试简单在线备用（免费公开接口，仅作演示）
 */
class TranslatorHelper {

    companion object {
        private const val TAG = "TranslatorHelper"
    }

    private var translator: Translator? = null
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private var modelReady = false

    /**
     * 初始化并下载离线模型（如果需要）
     */
    suspend fun prepare() {
        if (translator != null && modelReady) return

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.CHINESE)
            .build()

        translator = Translation.getClient(options)

        val conditions = DownloadConditions.Builder()
            .requireWifi()  // 首次下载建议 WiFi，可按需去掉
            .build()

        try {
            translator?.downloadModelIfNeeded(conditions)?.await()
            modelReady = true
            Log.d(TAG, "ML Kit 翻译模型已就绪")
        } catch (e: Exception) {
            Log.w(TAG, "离线模型下载失败，将尝试在线备用: ${e.message}")
            modelReady = false
        }
    }

    /**
     * 翻译英文到简体中文
     */
    suspend fun translate(text: String): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext ""

        // 1. 优先离线
        if (modelReady && translator != null) {
            try {
                val result = translator!!.translate(text).await()
                if (result.isNotBlank()) {
                    return@withContext result
                }
            } catch (e: Exception) {
                Log.w(TAG, "离线翻译失败: ${e.message}")
            }
        }

        // 2. 在线备用（简单演示接口，实际可换成自己的 API 或 DeepL 等）
        try {
            onlineTranslate(text)
        } catch (e: Exception) {
            Log.e(TAG, "在线翻译也失败: ${e.message}")
            "【翻译失败】$text"
        }
    }

    /**
     * 简单在线翻译备用（使用公开免费接口示例，仅供参考）
     * 生产环境请替换为自己的后端或正规 API
     */
    private fun onlineTranslate(text: String): String {
        // 这里用一个非常简化的示例，实际项目建议使用自己的服务器中转
        // 或者接入 Google Cloud Translation / DeepL / 腾讯翻译等
        val encoded = URLEncoder.encode(text.take(500), "UTF-8")
        // 注意：以下仅为结构示例，真实可用接口请自行替换
        val url = "https://api.mymemory.translated.net/get?q=$encoded&langpair=en|zh-CN"

        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
            val body = response.body?.string() ?: throw Exception("empty body")
            val json = JSONObject(body)
            val translated = json.optJSONObject("responseData")
                ?.optString("translatedText")
            return translated?.takeIf { it.isNotBlank() } ?: text
        }
    }

    fun close() {
        translator?.close()
        translator = null
        modelReady = false
    }
}
