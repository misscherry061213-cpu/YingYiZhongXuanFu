package com.example.screentranslate.util

/**
 * 简单的文本变化检测（用于自动模式判断是否需要重新翻译）
 */
object ImageDiffHelper {

    /**
     * 比较两段文本是否有实质变化
     * 忽略空白和大小写差异
     */
    fun hasSignificantChange(oldText: String?, newText: String?): Boolean {
        if (oldText == null && newText == null) return false
        if (oldText == null || newText == null) return true

        val normalize = { s: String ->
            s.replace("\\s+".toRegex(), " ").trim().lowercase()
        }

        return normalize(oldText) != normalize(newText)
    }

    /**
     * 简单哈希，用于快速判断
     */
    fun textHash(text: String?): Int {
        return text?.replace("\\s+".toRegex(), "")?.lowercase()?.hashCode() ?: 0
    }
}
