package com.example.screentranslate.service

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.example.screentranslate.R

/**
 * 顶部译文悬浮窗管理
 */
class OverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var tvTranslation: TextView? = null
    private var btnAuto: TextView? = null
    private var btnTranslate: TextView? = null
    private var btnClose: TextView? = null

    var onTranslateClick: (() -> Unit)? = null
    var onAutoToggle: (() -> Unit)? = null
    var onCloseClick: (() -> Unit)? = null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (overlayView != null) return

        val inflater = LayoutInflater.from(context)
        overlayView = inflater.inflate(R.layout.overlay_translation, null)

        tvTranslation = overlayView!!.findViewById(R.id.tvTranslation)
        btnAuto = overlayView!!.findViewById(R.id.btnAuto)
        btnTranslate = overlayView!!.findViewById(R.id.btnTranslate)
        btnClose = overlayView!!.findViewById(R.id.btnClose)

        btnTranslate?.setOnClickListener { onTranslateClick?.invoke() }
        btnAuto?.setOnClickListener { onAutoToggle?.invoke() }
        btnClose?.setOnClickListener { onCloseClick?.invoke() }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            x = 0
            y = 80  // 稍微避开状态栏
        }

        // 支持拖动
        var initialY = 0
        var initialTouchY = 0f
        overlayView!!.findViewById<View>(R.id.titleBar).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = layoutParams!!.y
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(overlayView, layoutParams)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(overlayView, layoutParams)
    }

    fun updateText(text: String) {
        tvTranslation?.text = text
    }

    fun setAutoMode(enabled: Boolean) {
        btnAuto?.text = if (enabled) "自动:开" else "自动:关"
    }

    fun hide() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlayView = null
        tvTranslation = null
        btnAuto = null
        btnTranslate = null
        btnClose = null
    }

    fun isShowing(): Boolean = overlayView != null
}
