package com.example.screentranslate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.screentranslate.databinding.ActivityMainBinding
import com.example.screentranslate.service.TranslateService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        updatePermissionStatus()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        updatePermissionStatus()
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, TranslateService::class.java).apply {
                action = TranslateService.ACTION_START
                putExtra(TranslateService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(TranslateService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, intent)
            binding.tvStatus.text = "状态：服务已启动（顶部浮窗已出现）"
            Toast.makeText(this, "翻译服务已启动", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "需要屏幕录制权限才能截屏翻译", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnOverlayPermission.setOnClickListener {
            requestOverlayPermission()
        }

        binding.btnNotificationPermission.setOnClickListener {
            requestNotificationPermission()
        }

        binding.btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授予「显示在其他应用上层」权限", Toast.LENGTH_LONG).show()
                requestOverlayPermission()
                return@setOnClickListener
            }
            // 请求 MediaProjection（截屏权限）
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent())
        }

        binding.btnStop.setOnClickListener {
            val intent = Intent(this, TranslateService::class.java).apply {
                action = TranslateService.ACTION_STOP
            }
            startService(intent)
            binding.tvStatus.text = "状态：已停止"
            Toast.makeText(this, "翻译服务已停止", Toast.LENGTH_SHORT).show()
        }

        updatePermissionStatus()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        overlayPermissionLauncher.launch(intent)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                Toast.makeText(this, "通知权限已授予", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "当前系统无需额外通知权限", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePermissionStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val notificationOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED
        } else true

        binding.btnOverlayPermission.text = if (overlayOk) {
            "1. 显示在其他应用上层 ✓"
        } else {
            "1. 显示在其他应用上层（未授权）"
        }

        binding.btnNotificationPermission.text = if (notificationOk) {
            "2. 通知权限 ✓"
        } else {
            "2. 通知权限（未授权）"
        }
    }
}
