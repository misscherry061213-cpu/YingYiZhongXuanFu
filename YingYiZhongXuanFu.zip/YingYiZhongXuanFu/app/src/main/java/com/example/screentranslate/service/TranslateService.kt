package com.example.screentranslate.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.screentranslate.MainActivity
import com.example.screentranslate.R
import com.example.screentranslate.ocr.TextRecognizerHelper
import com.example.screentranslate.translate.TranslatorHelper
import com.example.screentranslate.util.ImageDiffHelper
import com.example.screentranslate.util.ScreenCaptureHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 前台服务：负责截屏、OCR、翻译、悬浮窗、自动模式
 */
class TranslateService : Service() {

    companion object {
        const val ACTION_START = "com.example.screentranslate.ACTION_START"
        const val ACTION_STOP = "com.example.screentranslate.ACTION_STOP"
        const val ACTION_TRANSLATE_NOW = "com.example.screentranslate.ACTION_TRANSLATE_NOW"
        const val ACTION_TOGGLE_AUTO = "com.example.screentranslate.ACTION_TOGGLE_AUTO"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "translate_service_channel"
        private const val NOTIFICATION_ID = 1001
        private const val TAG = "TranslateService"

        private const val AUTO_INTERVAL_MS = 2500L  // 自动模式检查间隔
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var screenCaptureHelper: ScreenCaptureHelper? = null
    private var overlayManager: OverlayManager? = null
    private val textRecognizer = TextRecognizerHelper()
    private val translator = TranslatorHelper()

    private var autoMode = false
    private var autoJob: Job? = null
    private val handler = Handler(Looper.getMainLooper())

    private var lastTextHash = 0
    private var isTranslating = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        overlayManager = OverlayManager(this).apply {
            onTranslateClick = { doTranslate() }
            onAutoToggle = { toggleAutoMode() }
            onCloseClick = { stopSelfSafe() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }

                if (data != null) {
                    startForegroundWithNotification()
                    initCapture(resultCode, data)
                    overlayManager?.show()
                    // 预加载翻译模型
                    serviceScope.launch {
                        translator.prepare()
                    }
                }
            }
            ACTION_STOP -> stopSelfSafe()
            ACTION_TRANSLATE_NOW -> doTranslate()
            ACTION_TOGGLE_AUTO -> toggleAutoMode()
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification("服务运行中，点击可翻译或停止")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initCapture(resultCode: Int, data: Intent) {
        screenCaptureHelper = ScreenCaptureHelper(this).also {
            it.init(resultCode, data)
        }
    }

    private fun doTranslate() {
        if (isTranslating) return
        isTranslating = true
        overlayManager?.updateText("正在识别并翻译…")

        serviceScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    screenCaptureHelper?.capture()
                }

                if (bitmap == null) {
                    overlayManager?.updateText("截屏失败，请重试")
                    return@launch
                }

                val englishText = withContext(Dispatchers.IO) {
                    textRecognizer.recognize(bitmap)
                }
                bitmap.recycle()

                if (englishText.isBlank()) {
                    overlayManager?.updateText("未识别到英文文本")
                    lastTextHash = 0
                    return@launch
                }

                // 自动模式下判断是否有变化
                val newHash = ImageDiffHelper.textHash(englishText)
                if (autoMode && newHash == lastTextHash) {
                    // 内容没变，不更新
                    return@launch
                }
                lastTextHash = newHash

                val chinese = translator.translate(englishText)
                overlayManager?.updateText(chinese)

                updateNotification("已更新译文")
            } catch (e: Exception) {
                Log.e(TAG, "translate error", e)
                overlayManager?.updateText("翻译出错：${e.message}")
            } finally {
                isTranslating = false
            }
        }
    }

    private fun toggleAutoMode() {
        autoMode = !autoMode
        overlayManager?.setAutoMode(autoMode)

        if (autoMode) {
            startAutoLoop()
            updateNotification("自动模式已开启")
        } else {
            stopAutoLoop()
            updateNotification("自动模式已关闭")
        }
    }

    private fun startAutoLoop() {
        stopAutoLoop()
        autoJob = serviceScope.launch {
            while (autoMode) {
                doTranslate()
                kotlinx.coroutines.delay(AUTO_INTERVAL_MS)
            }
        }
    }

    private fun stopAutoLoop() {
        autoJob?.cancel()
        autoJob = null
    }

    private fun buildNotification(content: String): Notification {
        val mainIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val translateIntent = PendingIntent.getService(
            this, 1,
            Intent(this, TranslateService::class.java).setAction(ACTION_TRANSLATE_NOW),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.service_running))
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(mainIntent)
            .addAction(0, "立即翻译", translateIntent)
            .addAction(0, "停止", stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(content: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(content))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "英译中悬浮服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "屏幕翻译前台服务通知"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun stopSelfSafe() {
        stopAutoLoop()
        overlayManager?.hide()
        screenCaptureHelper?.release()
        textRecognizer.close()
        translator.close()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopSelfSafe()
        serviceScope.cancel()
        super.onDestroy()
    }
}
